package com.cg.superheroes.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.superheroes.beans.SuperHEroes;


@Repository
public interface SuperHeroesRepo extends JpaRepository<SuperHEroes, Long>{

}
