package com.cg.superheroes.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.superheroes.beans.SuperHEroes;
import com.cg.superheroes.repo.SuperHeroesRepo;

@RestController
public class URIController {
	@Autowired
	SuperHeroesRepo repo;
	
	@PostMapping(value = "/heroes")
	   public SuperHEroes addSuperHero(@RequestBody SuperHEroes superHeroes ) {
	      return repo.save(superHeroes);
	   }
	
	
	
	@GetMapping(value="/gethero")
	public List<SuperHEroes> getSuperHero( ) {
	      return repo.findAll();
	   }
	
	
	@GetMapping(value="/getherobyid/{id}")
	public SuperHEroes getSuperHErobyID(@PathVariable long id)
	{
		Optional<SuperHEroes> shero=repo.findById(id);
		return shero.get();
	}
	
	
	@DeleteMapping(value="/deletehero/{id}")
	public void deleteSuperHEro(@PathVariable long id)
	{
		repo.deleteById(id);
	}	
	
	@PutMapping(value="/updatehero/{id}")
	public SuperHEroes updateSuperHero(@RequestBody SuperHEroes sh,@PathVariable long id)
	{
		Optional<SuperHEroes> shero= repo.findById(id);
		
		if(shero.isPresent())
		
		sh.setId(id);
		
	return repo.save(sh);
	}
	
	
	
}
